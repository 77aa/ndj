void Light1_Pin_Init(void);
void Light1_On(void);
void Light1_Off(void);

void Light2_Pin_Init(void);
void Light2_On(void);
void Light2_Off(void);

