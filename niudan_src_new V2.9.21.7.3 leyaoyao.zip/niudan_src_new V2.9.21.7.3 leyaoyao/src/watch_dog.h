#include "stm32f10x.h"





void IWDG_Init(uint8_t prv ,uint16_t rlv);
void IWDG_Feed(void);


